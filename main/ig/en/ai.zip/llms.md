# ans.fhir.fr.test_ig_bpit#0.1.0: ANS IG Example(en)

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Contexte](contexte.md)
* [Gestion du catalogue](gestion_catalogue.md)
* [Licences](licences.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### ImplementationGuides

* [ANS IG Example](ImplementationGuide-ans.fhir.fr.test_ig_bpit.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
