# EyeColor - ANS IG Example v0.1.0

## Extension: 

Eye color extension

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [Patient français](StructureDefinition-fr-patient.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fhir.fr.test_ig_bpit|current/StructureDefinition/StructureDefinition-EyeColor.json)

### Formal Views of Extension Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-EyeColor.csv), [Excel](../StructureDefinition-EyeColor.xlsx), [Schematron](../StructureDefinition-EyeColor.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "EyeColor",
  "url" : "https://interop.esante.gouv.fr/ig/test_ig_bpit/StructureDefinition/EyeColor",
  "version" : "0.1.0",
  "name" : "EyeColor",
  "status" : "draft",
  "date" : "2026-07-23T06:55:30+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Eye color extension",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Element"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "definition" : "Eye color extension"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://interop.esante.gouv.fr/ig/test_ig_bpit/StructureDefinition/EyeColor"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://interop.esante.gouv.fr/ig/test_ig_bpit/ValueSet/EyeColorVS"
      }
    }]
  }
}

```
