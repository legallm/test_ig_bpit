# Glossaire - Test IG BPI v0.1.0

## Glossaire

 
There is no translation page available for the current page, so it has been rendered in the default language 

Les termes suivants sont utilisés dans ce document et peuvent nécessiter des besoins de précisions.

| | |
| :--- | :--- |
| Catalogue de ressources sémantique | Ensemble de ressource(s) sémantique(s) associée(s) à un Système d'Information |
| ENS | Entreprise du Numérique en Santé |
| Instance logicielle | Installation en production d'une version d'un logiciel sur un même serveur physique ou logique |
| Ressource sémantique | Alignement, jeux de valeurs ou Terminologies, base de connaissances ou système de règles d'échelle internationale, nationale ou locale |
| SMT | [Serveur Multi-Terminologies](https://smt.esante.gouv.fr/) |
| Système d'information (SI) | Application permettant la gestion de données de santé ou sociales de patients ou usagers |

